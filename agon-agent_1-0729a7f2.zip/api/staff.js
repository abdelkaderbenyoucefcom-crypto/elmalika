import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { email } = req.query;
      let q = supabase.from('staff_roles').select('*').order('created_at', { ascending: true });
      if (email) q = q.eq('email', String(email).toLowerCase());
      const { data, error } = await q;
      if (error) throw error;
      if (email) return res.status(200).json(data[0] || null);
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { email, display_name, role } = req.body || {};
      if (!email || !role) return res.status(400).json({ error: 'email and role required' });
      const { data, error } = await supabase.from('staff_roles').insert({
        email: String(email).toLowerCase().trim(),
        display_name: display_name || String(email).split('@')[0],
        role,
        is_active: true,
      }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, display_name, role, is_active } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const patch = {};
      if (display_name !== undefined) patch.display_name = display_name;
      if (role !== undefined) patch.role = role;
      if (is_active !== undefined) patch.is_active = is_active;
      const { data, error } = await supabase.from('staff_roles').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('staff_roles').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('staff API:', err);
    return res.status(500).json({ error: err.message });
  }
}
