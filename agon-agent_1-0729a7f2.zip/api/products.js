import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { slug, id, active } = req.query;
      let q = supabase.from('products').select('*').order('created_at', { ascending: false });
      if (slug) q = q.eq('slug', slug);
      if (id) q = q.eq('id', id);
      if (active === 'true') q = q.eq('is_active', true);
      const { data, error } = await q;
      if (error) throw error;
      if (slug || id) return res.status(200).json(data[0] || null);
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      if (!body.title || !body.slug || body.price == null) {
        return res.status(400).json({ error: 'title, slug and price are required' });
      }
      const { data, error } = await supabase.from('products').insert(body).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...rest } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { data, error } = await supabase.from('products').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('products API:', err);
    return res.status(500).json({ error: err.message });
  }
}
